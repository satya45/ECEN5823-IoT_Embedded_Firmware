#include "src/sleep.h"
#include "em_emu.h"
#include "em_core.h"



void blockSleepMode(sleepstate_enum minimumMode)
{
	CORE_ATOMIC_IRQ_DISABLE();
	sleep_block[minimumMode]++;
	CORE_ATOMIC_IRQ_ENABLE();

}
void unblockSleepMode(sleepstate_enum minimumMode)
{

	CORE_ATOMIC_IRQ_DISABLE();
	if (sleep_block[minimumMode]>0)
	{
		sleep_block[minimumMode]--;


	}
	CORE_ATOMIC_IRQ_ENABLE();

}



void sleep(void)	//sleep routine
{
	if (sleep_block[0]>0)
	{
		return;
	}
	else if (sleep_block[1]>0)
		{
			return;
		}
	else if (sleep_block[2]>0)
	{
			EMU_EnterEM1();
		}
	else if (sleep_block[3]>0)
		{
			EMU_EnterEM2(true);
		}
	else
	{
		EMU_EnterEM3(true);
	}
	return;


}

