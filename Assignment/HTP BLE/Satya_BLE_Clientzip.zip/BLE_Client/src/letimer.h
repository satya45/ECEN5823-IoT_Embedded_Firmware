#include "em_letimer.h"



void LETIMER0_IRQHandler(void);
void LetimerSetup(void);

