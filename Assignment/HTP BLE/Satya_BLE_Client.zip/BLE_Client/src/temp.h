/*
 * temp.h
 *
 *  Created on: Sep 21, 2018
 *      Author: satya
 */

#ifndef SRC_TEMP_H_
#define SRC_TEMP_H_

#define threshold 15;
float temp_read(void);
#endif /* SRC_TEMP_H_ */
