/*
 * timer0.h
 *
 *  Created on: Sep 30, 2018
 *      Author: satya
 */

#ifndef SRC_TIMER0_H_
#define SRC_TIMER0_H_

void timerinit();

#endif /* SRC_TIMER0_H_ */
